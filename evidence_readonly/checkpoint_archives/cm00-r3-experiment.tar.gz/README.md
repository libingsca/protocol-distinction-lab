# Protocol Distinction Lab

`CM00` performs exhaustive tabular searches for credit maturation:

```bash
python -m cm00.run --output results/cm00/run_name
python -m unittest discover -s tests -v
```

The implementation uses only the Python standard library. Historical neural checkpoints are not read or modified.

