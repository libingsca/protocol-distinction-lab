"""Experiment02: row or shared-input group targets. No evaluation data access."""
import argparse, sys, json, time
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from core import Sender,Receiver,codes,candidate_losses,state_hash,digest,dump,setup,legal_data
from group_targets2 import hard_targets
ROOT=Path(__file__).resolve().parent

def init_pair(init):
    with torch.random.fork_rng():
        torch.manual_seed(init+200000); s=Sender()
        torch.manual_seed(init+700000); r=Receiver()
    return s,r

def optim(model):
    return torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=0,betas=(.9,.999),eps=1e-8)

def update_sender(s,r,d,order,arm,target,opt):
    for p in r.parameters(): p.requires_grad_(False)
    r.zero_grad(set_to_none=True); s.requires_grad_(True)
    first=None; total=0.; norms=[]
    for ix in order.split(128):
        opt.zero_grad(set_to_none=True)
        if arm=='J-STE':
            z=r(s.message(d['x'][ix],d['q'][ix],True),d['q'][ix],d['r'][ix])
            loss=F.binary_cross_entropy_with_logits(z,d['y'][ix])
        else: loss=F.binary_cross_entropy_with_logits(s.logits(d['x'][ix],d['q'][ix]),target[ix])
        loss.backward()
        assert torch.isfinite(loss) and all(p.grad is None or torch.isfinite(p.grad).all() for p in s.parameters())
        if first is None: first={'loss':loss.detach().clone(),'grads':{k:p.grad.clone() for k,p in s.named_parameters()}}
        norms.append(float(sum((p.grad**2).sum() for p in s.parameters() if p.grad is not None).sqrt()))
        opt.step(); total+=float(loss.detach())*len(ix)
    return first,{'sender_loss':total/len(order),'sender_gradient_norm':float(np.mean(norms))}

def update_receiver(s,r,d,order,opt):
    s.requires_grad_(False); s.zero_grad(set_to_none=True); r.requires_grad_(True)
    first=None; total=0.
    for ix in order.split(128):
        opt.zero_grad(set_to_none=True)
        with torch.no_grad(): m=s.message(d['x'][ix],d['q'][ix])
        loss=F.binary_cross_entropy_with_logits(r(m,d['q'][ix],d['r'][ix]),d['y'][ix]); loss.backward()
        assert torch.isfinite(loss) and all(torch.isfinite(p.grad).all() for p in r.parameters())
        if first is None: first={'loss':loss.detach().clone(),'grads':{k:p.grad.clone() for k,p in r.named_parameters()}}
        opt.step(); total+=float(loss.detach())*len(ix)
    return first,total/len(order)

def snapshot(s,r,so,ro):
    return {'sender':s.state_dict(),'receiver':r.state_dict(),'sender_optimizer':so.state_dict(),'receiver_optimizer':None if ro is None else ro.state_dict()}

def install_guard(run,out,allowed):
    project=ROOT.parent.resolve(); reads=set()
    allowed={str(p.resolve()) for p in allowed}
    def guard(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes)): return
        p=Path(args[0]).resolve()
        if not p.is_relative_to(project): return
        if p.is_relative_to(Path(sys.prefix).resolve()): return
        if p.is_relative_to(out): return
        if p.parent==ROOT and p.suffix=='.py': return
        if p.is_relative_to(ROOT/'__pycache__'): return
        if str(p) not in allowed: raise PermissionError('Training project-file whitelist rejected: '+str(p))
        reads.add(str(p))
    sys.addaudithook(guard)
    return reads

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('run'); ap.add_argument('split',type=int); ap.add_argument('init',type=int); ap.add_argument('arm'); a=ap.parse_args()
    setup(); run=Path(a.run).resolve(); cfg=json.loads((run/'resolved_config.json').read_text())
    assert cfg['epochs']==100 and a.arm in cfg['arms']
    assert json.loads((run/'preflight.json').read_text())['passed']
    for rel,h in json.loads((run/'frozen_manifest.json').read_text()).items(): assert digest(ROOT/rel)==h,rel
    tag=f'{a.split}_{a.init}'; out=run/'models'/f'{tag}_{a.arm}'; out.mkdir(parents=True,exist_ok=False)
    train=run/f'train_{a.split}.npz'; groupfile=run/f'groups_{a.split}.npy'
    allowed=[train]+([groupfile] if a.arm=='J-GROUP16' else [])
    reads=install_guard(run,out,allowed)
    t0=time.monotonic(); d=legal_data(train); s,r=init_pair(a.init)
    indices=np.load(groupfile) if a.arm=='J-GROUP16' else None
    so=optim(s); ro=optim(r)
    torch.save(snapshot(s,r,so,ro),out/'epoch000.pt')
    sg=torch.Generator().manual_seed(a.split*10000+a.init+2)
    rg=torch.Generator().manual_seed(a.split*10000+a.init+3)
    orders=[]; rorders=[]; logs=[]; scoring=0.; sender_time=0.; receiver_time=0.; target=None; queries=0
    for e in range(1,101):
        if a.arm in ['J-ROW16','J-GROUP16']:
            t=time.monotonic(); losses=candidate_losses(r,d['q'],d['r'],d['y'])
            target,choice=hard_targets(losses,indices); queries+=len(d['q'])*16
            np.save(out/f'targets{e:03}.npy',choice.numpy())
            np.save(out/f'scores{e:03}.npy',losses.numpy()); scoring+=time.monotonic()-t
        order=torch.randperm(len(d['q']),generator=sg); orders.append(order.numpy())
        rh=state_hash(r.state_dict()); t=time.monotonic()
        fs,log=update_sender(s,r,d,order,a.arm,target,so); sender_time+=time.monotonic()-t
        assert state_hash(r.state_dict())==rh and all(p.grad is None for p in r.parameters())
        torch.save(snapshot(s,r,so,ro),out/f'epoch{e:03}_sender.pt')
        if e==1: torch.save(fs,out/'first_sender.pt')
        if ro is not None:
            order_r=torch.randperm(len(d['q']),generator=rg); rorders.append(order_r.numpy()); sh=state_hash(s.state_dict()); t=time.monotonic()
            fr,rl=update_receiver(s,r,d,order_r,ro); receiver_time+=time.monotonic()-t
            assert state_hash(s.state_dict())==sh and all(p.grad is None for p in s.parameters())
            log['receiver_loss']=rl
            if e==1: torch.save(fr,out/'first_receiver.pt')
        torch.save(snapshot(s,r,so,ro),out/f'epoch{e:03}.pt'); logs.append({'epoch':e,**log})
        if e%25==0: print(f'{tag} {a.arm}: {e}/100 epochs completed',flush=True)
    torch.save({'sender':s.state_dict(),'receiver':r.state_dict()},out/'checkpoint.pt')
    np.savez(out/'orders.npz',sender=np.array(orders),receiver=np.array(rorders))
    dump(out/'training_curves.json',logs)
    meta={'split':a.split,'init':a.init,'arm':a.arm,'epochs':100,'sender_updates':3200,'receiver_updates':0 if ro is None else 3200,'candidate_queries':queries,'candidate_batches':queries//2048,'sender_task_receiver_forwards':409600 if a.arm=='J-STE' else 0,'receiver_training_forwards':0 if ro is None else 409600,'training_evaluation_forwards':0,'scoring_seconds':scoring,'sender_seconds':sender_time,'receiver_seconds':receiver_time,'elapsed_seconds':time.monotonic()-t0,'project_inputs_read':sorted(reads),'final_sender_hash':state_hash(s.state_dict()),'final_receiver_hash':state_hash(r.state_dict())}
    dump(out/'training.json',meta); print(f'{tag} {a.arm}: sealed',flush=True)
if __name__=='__main__': main()
