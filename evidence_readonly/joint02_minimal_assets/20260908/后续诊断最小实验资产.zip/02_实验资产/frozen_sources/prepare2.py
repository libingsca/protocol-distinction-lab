"""Preflight and freeze experiment02 without observing new formal learning outcomes."""
import sys,json,time,platform,shutil,subprocess
from pathlib import Path
import numpy as np
import torch
from core import setup,dump,digest,candidate_losses,state_hash,legal_data
from train_model2 import init_pair,optim,update_sender,update_receiver,install_guard
from group_targets2 import group_indices,hard_targets
from audit2 import independent_groups,independent_targets
from audit_v2 import universe,params,opt,score,sender_pass,receiver_pass,same
ROOT=Path(__file__).resolve().parent

def probe(folder,mode):
    setup();folder=Path(folder).resolve();out=folder/f'out_{mode}';out.mkdir()
    decoy=folder/'evaluation_only.npz'
    if mode=='absent':
        if decoy.exists():decoy.unlink()
    else:np.savez(decoy,V=np.full(10,0 if mode=='zero' else 777))
    legal=folder/'legal.npz';gf=folder/'groups.npy';reads=install_guard(folder,out,[legal,gf]);denied=0
    for p in [decoy,ROOT/'results/20260907-joint01-r2/models/9001_9201_P-E16/checkpoint.pt',folder/'other_arm/scores001.npy']:
        try:
            with open(p,'rb'):pass
        except PermissionError:denied+=1
    assert denied==3
    d=legal_data(legal);gi=np.load(gf);s,r=init_pair(77123);loss=candidate_losses(r,d['q'],d['r'],d['y']);target,choice=hard_targets(loss,gi)
    so=optim(s);ro=optim(r);order=torch.arange(len(d['q']))
    update_sender(s,r,d,order,'J-GROUP16',target,so);update_receiver(s,r,d,order,ro)
    dump(out/'result.json',{'sender':state_hash(s.state_dict()),'receiver':state_hash(r.state_dict()),'target':state_hash({'choice':choice}),'denied':denied,'reads':sorted(reads)})

def main():
    setup();run=ROOT/'results'/sys.argv[1];run.mkdir(parents=True,exist_ok=False);prev=ROOT/'results/20260907-joint01-r2';old=ROOT.parent/'discrete_counterfactual_credit/results/20260907-exp09';checks=[]
    def ck(n,b):
        checks.append({'name':n,'passed':bool(b)})
        if not b:dump(run/'preflight.json',{'passed':False,'checks':checks});raise AssertionError(n)
    ck('previous_audit_valid',json.loads((prev/'audit.json').read_text())['passed'])
    actual={'python':sys.version,'numpy':np.__version__,'torch':torch.__version__,'platform':platform.platform(),'threads':torch.get_num_threads()}
    ck('same_environment',actual==json.loads((prev/'environment_actual.json').read_text()))
    u,v=universe();z=np.load(old/'evaluation_only.npz')
    for k in u:ck('full8192_'+k,np.array_equal(u[k],z[k]))
    ck('full8192_V',np.array_equal(v,z['v']))
    sources={str(p):digest(p) for p in [prev/'audit.json',prev/'CLOSURE_MANIFEST.json',prev/'training_manifest.json',prev/'environment_actual.json',old/'evaluation_only.npz']}
    prior_manifest=json.loads((prev/'training_manifest.json').read_text())
    for rel,h in prior_manifest.items():
        if '_J-E16/' in rel:
            ck('historical_anchor_'+rel,digest(prev/rel)==h);sources[str(prev/rel)]=h
    for split in [9001,9002,9003]:
        xp=np.random.Generator(np.random.PCG64(split)).permutation(256);parts=[np.flatnonzero(np.isin(np.arange(8192)//32,xx)) for xx in [xp[:128],xp[128:160],xp[160:]]]
        ck(f'{split}_partition',list(map(len,parts))==[4096,1024,3072] and sorted(np.concatenate(parts))==list(range(8192)))
        src=prev/f'train_{split}.npz';raw=dict(np.load(src));ck(f'{split}_legal_fields',set(raw)==set(u))
        for k in u:ck(f'{split}_train_{k}',np.array_equal(raw[k],u[k][parts[0]]))
        gi=group_indices(raw['x'],raw['q'],raw['r']);ind=independent_groups(raw['x'],raw['q'],raw['r']);ck(f'{split}_independent_groups',np.array_equal(gi,ind) and gi.shape==(256,16))
        shutil.copyfile(src,run/src.name);np.save(run/f'groups_{split}.npy',gi);sources[str(src)]=digest(src)
    rng=np.random.Generator(np.random.PCG64(77123));x=((np.arange(256)[:,None]//(2**np.arange(8)))%2).repeat(16,0)
    q=rng.integers(0,2,256).repeat(16);r=np.tile(((np.arange(16)[:,None]//(2**np.arange(4)))%2),(256,1));y=rng.integers(0,2,(4096,4))
    raw={'x':x,'q':q,'r':r,'y':y};d={k:torch.tensor(v,dtype=torch.int64 if k=='q' else torch.float32) for k,v in raw.items()};gi=group_indices(x,q,r)
    timings={}
    for arm in ['J-ROW16','J-GROUP16']:
        start=time.monotonic();s,rc=init_pair(77123);sp=params(s.state_dict());rp=params(rc.state_dict());so=optim(s);ro=optim(rc);sop=opt(sp);rop=opt(rp)
        ls=candidate_losses(rc,d['q'],d['r'],d['y']);li=score(rp,d);ck(arm+'_scores',torch.equal(ls,li))
        target,choice=hard_targets(ls,gi if arm=='J-GROUP16' else None);target_i,choice_i=independent_targets(li,gi,arm=='J-GROUP16');ck(arm+'_targets',torch.equal(target,target_i) and torch.equal(choice,choice_i))
        order=torch.randperm(4096,generator=torch.Generator().manual_seed(998877));f,_=update_sender(s,rc,d,order,arm,target,so);fi=sender_pass(sp,rp,d,order,'J-E16',target_i,sop)
        ck(arm+'_sender_gradient',same(f,fi));ck(arm+'_sender_state',same(s.state_dict(),sp) and same(rc.state_dict(),rp) and same(so.state_dict(),sop.state_dict()))
        f,_=update_receiver(s,rc,d,order,ro);fi=receiver_pass(sp,rp,d,order,rop);ck(arm+'_receiver_gradient',same(f,fi));ck(arm+'_receiver_state',same(s.state_dict(),sp) and same(rc.state_dict(),rp) and same(ro.state_dict(),rop.state_dict()))
        timings[arm]=time.monotonic()-start
    special=torch.full((16,16),100.);special[:9,0]=0;special[:9,1]=1;special[9:,0]=10;special[9:,1]=0
    t,c=hard_targets(special,np.arange(16)[None,:]);ck('mean_loss_not_majority_vote',bool((c==1).all()) and int(special.argmin(1).mode().values)==0)
    t,c=hard_targets(torch.zeros(16,16),np.arange(16)[None,:]);ck('lowest_numeric_tie',bool((c==0).all()))
    permutation=rng.permutation(4096);gip=group_indices(x[permutation],q[permutation],r[permutation]);t1,c1=hard_targets(ls,gi);t2,c2=hard_targets(ls[permutation],gip);restored=np.empty(4096,dtype=int);restored[permutation]=c2.numpy();ck('grouping_row_order_invariant',np.array_equal(restored,c1.numpy()))
    folder=run/'synthetic_permissions';folder.mkdir();np.savez(folder/'legal.npz',**{k:v[:128] for k,v in raw.items()});np.save(folder/'groups.npy',np.arange(128).reshape(8,16))
    for mode in ['absent','zero','changed']:subprocess.run([sys.executable,str(ROOT/'prepare2.py'),'--probe',str(folder),mode],check=True)
    probes=[json.loads((folder/f'out_{m}/result.json').read_text()) for m in ['absent','zero','changed']];ck('missing_decoy_V_and_other_arm_noninterference',probes[0]==probes[1]==probes[2])
    estimate=sum(timings.values())*600;ck('fixed3600second_budget_feasible',estimate<3600)
    cfg={'experiment':'joint_protocol_learning_02','splits':[9001,9002,9003],'inits':[9201,9202],'arms':['J-ROW16','J-GROUP16'],'epochs':100,'batch_size':128,'timeout_seconds':3600,'sender_seed':'init+200000','receiver_seed':'init+700000','sender_order_seed':'split*10000+init+2','receiver_order_seed':'split*10000+init+3','optimizer':{'name':'AdamW','lr':.001,'weight_decay':0,'betas':[.9,.999],'eps':1e-8},'score_precision':'float32','group_reduction':'float64 mean in r=0..15 order, argmin numeric tie','training_precision':'float32','group_identity':'first occurrence of identical legal(x,q), no semantics','checkpoint':'epoch100_after_receiver','gate_task_gain':.1,'gate_code_gain':.1,'gate_each_split_both_positive':True,'gate_recovery':.95,'gate_constant_drop':.8,'source_run':prev.name,'train_candidate_scores':78643200,'sender_updates':38400,'receiver_updates':38400}
    dump(run/'resolved_config.json',cfg);dump(run/'environment_actual.json',actual);dump(run/'source_manifest.json',sources)
    dump(run/'preflight.json',{'passed':True,'count':len(checks),'checks':checks,'synthetic_timings_including_independent_replay':timings,'conservative_estimate_seconds':estimate,'formal_model_learning_not_inspected':True})
    names=['core.py','group_targets2.py','train_model2.py','audit_v2.py','audit2.py','prepare2.py','run2.py','EXPERIMENT_02_PLAN.md']
    (run/'frozen_sources').mkdir()
    for n in names:shutil.copyfile(ROOT/n,run/'frozen_sources'/n)
    dump(run/'frozen_manifest.json',{n:digest(ROOT/n) for n in names})
    inputs=[run/n for n in ['resolved_config.json','environment_actual.json','source_manifest.json','preflight.json']]+list(run.glob('train_*.npz'))+list(run.glob('groups_*.npy'))
    dump(run/'input_manifest.json',{str(p.relative_to(run)):digest(p) for p in inputs});dump(run/'status.json',{'status':'frozen_ready','completed_models':0})
    print(json.dumps({'run':str(run),'preflight_checks':len(checks),'conservative_estimate_seconds':estimate}),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='--probe':probe(sys.argv[2],sys.argv[3])
    else:main()
