import sys,json,time,subprocess
from pathlib import Path
from core import dump,digest
ROOT=Path(__file__).resolve().parent
run=Path(sys.argv[1]).resolve();cfg=json.loads((run/'resolved_config.json').read_text())
assert json.loads((run/'status.json').read_text())['status']=='frozen_ready'
for rel,h in json.loads((run/'frozen_manifest.json').read_text()).items():assert digest(ROOT/rel)==h
for rel,h in json.loads((run/'input_manifest.json').read_text()).items():assert digest(run/rel)==h
start=time.monotonic();completed=0;status='failed_implementation'
try:
    for split in cfg['splits']:
        for init in cfg['inits']:
            for arm in cfg['arms']:
                dump(run/'status.json',{'status':'running','completed_models':completed,'current':f'{split}_{init}_{arm}','elapsed_seconds':time.monotonic()-start})
                remaining=cfg['timeout_seconds']-(time.monotonic()-start)
                if remaining<=0:raise TimeoutError('Frozen training limit')
                subprocess.run([sys.executable,str(ROOT/'train_model2.py'),str(run),str(split),str(init),arm],check=True,timeout=remaining)
                completed+=1
    status='completed_pending_audit'
except BaseException as e:
    status='incomplete' if isinstance(e,(TimeoutError,subprocess.TimeoutExpired)) else 'failed_implementation'
    dump(run/'failure.json',{'type':type(e).__name__,'message':str(e)});raise
finally:
    dump(run/'status.json',{'status':status,'completed_models':completed,'elapsed_seconds':time.monotonic()-start})
    dump(run/'training_manifest.json',{str(p.relative_to(run)):digest(p) for p in sorted((run/'models').rglob('*')) if p.is_file()})
