"""Training-only grouping by observable identity; no task semantics."""
import numpy as np
import torch
from core import codes

def group_indices(x,q,r):
    groups={}
    for i in range(len(q)):
        key=tuple(x[i].tolist())+(int(q[i]),)
        groups.setdefault(key,[]).append(i)
    rows=[]
    for inds in groups.values():
        ordered=sorted(inds,key=lambda i:sum(int(r[i,b])*2**b for b in range(4)))
        assert len(ordered)==16
        assert [sum(int(r[i,b])*2**b for b in range(4)) for i in ordered]==list(range(16))
        rows.append(ordered)
    result=np.array(rows,dtype=np.int64)
    assert sorted(result.ravel().tolist())==list(range(len(q)))
    return result

def hard_targets(losses,indices=None):
    if indices is None:choice=losses.argmin(1)
    else:
        a=losses.detach().numpy()
        means=a[indices].astype(np.float64).mean(axis=1)
        chosen=means.argmin(axis=1)
        choices=np.empty(len(a),dtype=np.int64)
        choices[indices]=chosen[:,None]
        choice=torch.from_numpy(choices)
    return codes()[choice],choice
