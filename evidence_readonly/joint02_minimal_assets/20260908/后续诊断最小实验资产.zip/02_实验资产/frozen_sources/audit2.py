"""Experiment02 independent target construction and full functional optimizer replay."""
import sys,json,time
from pathlib import Path
import numpy as np
import torch
from core import dump,digest,setup
from audit_v2 import params,opt,sender_pass,receiver_pass,score,same,load,data,universe,evaluate,conflict,send,receive
ROOT=Path(__file__).resolve().parent

def independent_groups(x,q,r):
    identity=np.concatenate([np.asarray(x),np.asarray(q)[:,None]],axis=1)
    unique,first,inverse=np.unique(identity,axis=0,return_index=True,return_inverse=True)
    order=np.argsort(first);rv=np.asarray(r)@np.array([1,2,4,8])
    rows=[]
    for gid in order:
        idx=np.flatnonzero(inverse==gid);idx=idx[np.argsort(rv[idx])]
        assert len(idx)==16 and np.array_equal(rv[idx],np.arange(16))
        rows.append(idx)
    return np.stack(rows)

def independent_targets(losses,indices,grouped):
    if not grouped:ids=losses.argmin(1)
    else:
        a=losses.numpy();selected=np.empty(len(a),dtype=np.int64)
        for rows in indices:
            total=np.zeros(16,dtype=np.float64)
            for row in rows:total+=a[row].astype(np.float64)
            code=min(range(16),key=lambda c:(total[c]/16,c))
            selected[rows]=code
        ids=torch.tensor(selected)
    target=((ids[:,None]//(2**torch.arange(4)))%2).float()
    return target,ids

def main():
    run=Path(sys.argv[1]).resolve();setup();started=time.monotonic();checks=[]
    def ck(name,ok):
        checks.append({'name':name,'passed':bool(ok)})
        if not ok:
            dump(run/'audit.json',{'passed':False,'count':len(checks),'checks':checks});raise AssertionError(name)
    cfg=json.loads((run/'resolved_config.json').read_text());old=ROOT/'results/20260907-joint01-r2'
    status=json.loads((run/'status.json').read_text())
    ck('all_training_sealed',status['status'] in ['completed_pending_audit','completed_audited'] and status['completed_models']==12)
    for name,base in [('frozen_manifest.json',ROOT),('input_manifest.json',run),('training_manifest.json',run)]:
        for rel,h in json.loads((run/name).read_text()).items():ck(name+':'+rel,digest(base/rel)==h)
    for p,h in json.loads((run/'source_manifest.json').read_text()).items():ck('historical:'+p,digest(p)==h)
    ck('preflight_passed',json.loads((run/'preflight.json').read_text())['passed'])
    u,v=universe();models=[];diagnostics={}
    for split in cfg['splits']:
        xp=np.random.Generator(np.random.PCG64(split)).permutation(256)
        parts={p:np.flatnonzero(np.isin(np.arange(8192)//32,xx)) for p,xx in [('train',xp[:128]),('validation',xp[128:160]),('test',xp[160:])]}
        ck(f'{split}_partition',sorted(np.concatenate(list(parts.values())))==list(range(8192)) and [len(ix) for ix in parts.values()]==[4096,1024,3072])
        raw={k:u[k][parts['train']] for k in u};d=data(raw);vt=v[parts['train']];legal=dict(np.load(run/f'train_{split}.npz'))
        ck(f'{split}_legal_fields',set(legal)==set(raw))
        for k in raw:ck(f'{split}_data_{k}',np.array_equal(raw[k],legal[k]))
        gi=independent_groups(raw['x'],raw['q'],raw['r']);ck(f'{split}_group_ids',np.array_equal(gi,np.load(run/f'groups_{split}.npy')))
        ck(f'{split}_all_rows_once',np.array_equal(np.sort(gi.ravel()),np.arange(4096)))
        for init in cfg['inits']:
            initials={}
            for arm in cfg['arms']:
                name=f'{split}_{init}_{arm}';out=run/'models'/name;initial=load(out/'epoch000.pt');initials[arm]=initial
                s=params(initial['sender']);r=params(initial['receiver']);so=opt(s);ro=opt(r)
                sg=torch.Generator().manual_seed(split*10000+init+2);rg=torch.Generator().manual_seed(split*10000+init+3)
                orders=np.load(out/'orders.npz');ck(name+'_orders_shape',orders['sender'].shape==orders['receiver'].shape==(100,4096))
                anchor=old/'models'/f'{split}_{init}_J-E16';trajectory=[];probabilities=[];trainprob=[];previous=None;prev_actual=None;prev_m=None
                for e in range(1,101):
                    loss=score(r,d);ck(f'{name}_{e}_scores',np.array_equal(loss.numpy(),np.load(out/f'scores{e:03}.npy')))
                    target,choice=independent_targets(loss,gi,arm=='J-GROUP16');ck(f'{name}_{e}_targets',np.array_equal(choice.numpy(),np.load(out/f'targets{e:03}.npy')))
                    if arm=='J-GROUP16':ck(f'{name}_{e}_shared_target',bool((choice.numpy()[gi]==choice.numpy()[gi][:,:1]).all()))
                    row={'epoch':e};rawdiag,previous,probs=conflict(loss,previous);row.update(rawdiag);probabilities.append(probs)
                    actual_probs=target.numpy()[gi].mean(1);trainprob.append(actual_probs)
                    row['training_target_consistency']=float((choice.numpy()[gi]==choice.numpy()[gi][:,:1]).all(1).mean())
                    if prev_actual is not None:row['training_target_flip']=float((choice.numpy()!=prev_actual).mean())
                    prev_actual=choice.numpy().copy()
                    row['before'],_=evaluate(s,r,d,vt);old_r={k:p.detach().clone() for k,p in r.items()}
                    order=torch.randperm(4096,generator=sg);ck(f'{name}_{e}_sender_order',np.array_equal(order.numpy(),orders['sender'][e-1]))
                    fs=sender_pass(s,r,d,order,'J-E16',target,so)
                    mid=load(out/f'epoch{e:03}_sender.pt')
                    ck(f'{name}_{e}_sender_stage',same(s,mid['sender']) and same(r,mid['receiver']) and same(so.state_dict(),mid['sender_optimizer']) and same(ro.state_dict(),mid['receiver_optimizer']))
                    ck(f'{name}_{e}_receiver_frozen',same(r,old_r))
                    if e==1:ck(name+'_first_sender_gradient',same(fs,load(out/'first_sender.pt')))
                    row['after_sender'],_=evaluate(s,r,d,vt)
                    with torch.no_grad():_,msg=send(s,d['x'],d['q'])
                    msgbits=msg.numpy()[:,:4];mc=(msgbits[gi[:,0]]@np.array([1,2,4,8])).astype(int)
                    meanloss=loss.numpy()[gi].astype(np.float64).mean(1);regret=meanloss[np.arange(len(gi)),mc]-meanloss.min(1)
                    ck(f'{name}_{e}_shared_regret_nonnegative',regret.min()>=-1e-12)
                    row['shared_message_regret']=float(regret.mean());row['shared_message_regret_max']=float(regret.max())
                    row['target_bit_fit']=float((msgbits==target.numpy()).mean());row['target_code_fit']=float((msgbits==target.numpy()).all(1).mean())
                    order_r=torch.randperm(4096,generator=rg);ck(f'{name}_{e}_receiver_order',np.array_equal(order_r.numpy(),orders['receiver'][e-1]))
                    fr=receiver_pass(s,r,d,order_r,ro)
                    end=load(out/f'epoch{e:03}.pt');ck(f'{name}_{e}_receiver_stage',same(s,end['sender']) and same(r,end['receiver']) and same(so.state_dict(),end['sender_optimizer']) and same(ro.state_dict(),end['receiver_optimizer']))
                    ck(f'{name}_{e}_sender_frozen',same(s,mid['sender']))
                    if e==1:ck(name+'_first_receiver_gradient',same(fr,load(out/'first_receiver.pt')))
                    if arm=='J-ROW16':
                        ck(f'{name}_{e}_historical_stage',same(mid,load(anchor/f'epoch{e:03}_sender.pt')) and same(end,load(anchor/f'epoch{e:03}.pt')))
                        ck(f'{name}_{e}_historical_scores',np.array_equal(loss.numpy(),np.load(anchor/f'scores{e:03}.npy')))
                    row['after_receiver'],mcode=evaluate(s,r,d,vt)
                    if prev_m is not None:row['message_flip']=float((mcode!=prev_m).mean())
                    prev_m=mcode;trajectory.append(row)
                final=load(out/'checkpoint.pt');ck(name+'_final',same(s,final['sender']) and same(r,final['receiver']))
                ck(name+'_finite',all(torch.isfinite(p).all() for p in list(s.values())+list(r.values())))
                meta=json.loads((out/'training.json').read_text());ck(name+'_budget',meta['candidate_queries']==6553600 and meta['candidate_batches']==3200 and meta['sender_updates']==meta['receiver_updates']==3200 and meta['training_evaluation_forwards']==0)
                ck(name+'_optimizer_steps',all(int(st['step'])==3200 for o in (so,ro) for st in o.state_dict()['state'].values()))
                ck(name+'_score_count',len(list(out.glob('scores*.npy')))==len(list(out.glob('targets*.npy')))==100)
                allowed=[str(run/f'train_{split}.npz')]+([str(run/f'groups_{split}.npy')] if arm=='J-GROUP16' else [])
                ck(name+'_input_whitelist',meta['project_inputs_read']==sorted(allowed))
                if arm=='J-ROW16':
                    ck(name+'_historical_final',same(final,load(anchor/'checkpoint.pt')))
                    ck(name+'_historical_initial',same(initial,load(anchor/'epoch000.pt')))
                    ck(name+'_historical_first_gradients',same(load(out/'first_sender.pt'),load(anchor/'first_sender.pt')) and same(load(out/'first_receiver.pt'),load(anchor/'first_receiver.pt')))
                metrics={'split':split,'init':init,'arm':arm,'cost':meta}
                for part,ix in parts.items():metrics[part],_=evaluate(s,r,data({k:u[k][ix] for k in u}),v[ix],constants=part=='test')
                from core import Sender,Receiver,predict
                ns=Sender();nr=Receiver();ns.load_state_dict(final['sender']);nr.load_state_dict(final['receiver']);td=data({k:u[k][parts['test']] for k in u})
                _,z,_=predict(ns,nr,td)
                with torch.no_grad():_,m=send(s,td['x'],td['q']);zz=receive(r,m,td['q'],td['r'])
                ck(name+'_independent_predictions',torch.equal(z,zz))
                models.append(metrics);diagnostics[name]=trajectory
                np.savez_compressed(run/f'{name}_bit_probabilities.npz',raw_row_targets=np.array(probabilities),training_targets=np.array(trainprob))
                dump(run/'audit_progress.json',{'models_replayed':len(models),'checks':len(checks),'seconds':time.monotonic()-started})
                print(f'Audit {len(models)}/12 {name} exact replay passed',flush=True)
            ck(f'{split}_{init}_paired_initial',same(initials['J-ROW16'],initials['J-GROUP16']))
            with torch.random.fork_rng():
                torch.manual_seed(init+200000);ss=Sender();torch.manual_seed(init+700000);rr=Receiver()
            ck(f'{split}_{init}_random_initial',same(ss.state_dict(),initials['J-ROW16']['sender']) and same(rr.state_dict(),initials['J-ROW16']['receiver']))
            first=[np.load(run/'models'/f'{split}_{init}_{arm}'/'scores001.npy') for arm in cfg['arms']]
            ck(f'{split}_{init}_paired_first_scores',np.array_equal(*first))
    ck('12_models',len(models)==12)
    pairs=[]
    for split in cfg['splits']:
        for init in cfg['inits']:
            arms={m['arm']:m for m in models if m['split']==split and m['init']==init};a=arms['J-GROUP16'];b=arms['J-ROW16']
            pairs.append({'split':split,'init':init,'test_difference':a['test']['accuracy']-b['test']['accuracy'],'code_difference':a['test']['A_code']-b['test']['A_code']})
    means={k:float(np.mean([p[k] for p in pairs])) for k in ['test_difference','code_difference']}
    splits={str(s):{k:float(np.mean([p[k] for p in pairs if p['split']==s])) for k in means} for s in cfg['splits']}
    recovery={arm:all(m['test']['accuracy']>=.95 and m['test']['A_code']>=.95 and m['test']['constant_drop']>=.8 for m in models if m['arm']==arm) for arm in cfg['arms']}
    gates={'G0_valid':True,'G1_mechanism_improvement':all(v>=.1 for v in means.values()) and all(v>0 for d in splits.values() for v in d.values()),'G2_full_recovery':recovery['J-GROUP16'],'paired_means':means,'split_differences':splits,'recovery_by_arm':recovery}
    dump(run/'metrics.json',models);dump(run/'diagnostics.json',diagnostics);dump(run/'paired_results.json',pairs)
    dump(run/'audit.json',{'passed':True,'count':len(checks),'checks':checks,'gates':gates,'elapsed_seconds':time.monotonic()-started,'external_replication':False,'full_optimizer_replay':True,'audit_candidate_scores':78643200,'trajectory_forward_states':14745600,'final_evaluation_forward_states':12*8192,'constant_intervention_forward_states':12*16*3072,'extra_prediction_crosscheck_states':12*2*3072})
    print(json.dumps(gates,indent=2),flush=True)
if __name__=='__main__':main()
