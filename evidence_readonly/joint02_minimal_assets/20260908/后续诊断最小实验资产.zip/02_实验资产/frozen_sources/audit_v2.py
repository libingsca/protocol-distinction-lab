"""Independent functional-network reconstruction, full optimizer replay and evaluation.
Does not call training loops, candidate_losses, Sender.forward or Receiver.forward.
"""
import json,time,sys
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from core import dump,digest,setup,state_hash
ROOT=Path(__file__).resolve().parent

def params(state): return {k:torch.nn.Parameter(v.clone()) for k,v in state.items()}
def net(p,a):
    for i in (0,2,4):
        a=F.linear(a,p[f'net.{i}.weight'],p[f'net.{i}.bias'])
        if i!=4:a=F.relu(a)
    return a

def send(p,x,q,ste=False):
    z=net(p,torch.cat([x,F.one_hot(q,2).float()],1))[:,:4]
    h=(z>=0).float()
    if ste: h=h.detach()-z.sigmoid().detach()+z.sigmoid()
    return z,torch.cat([h,torch.zeros_like(h)],1)

def receive(p,m,q,r):
    mask=torch.cat([torch.ones_like(m[:,:4]),torch.zeros_like(m[:,:4])],1)
    return net(p,torch.cat([m,mask,F.one_hot(q,2).float(),r],1))

def opt(p): return torch.optim.AdamW(list(p.values()),lr=.001,weight_decay=0,betas=(.9,.999),eps=1e-8)

def sender_pass(s,r,d,order,arm,target,o):
    for p in s.values(): p.requires_grad_(True)
    for p in r.values(): p.requires_grad_(False);p.grad=None
    first=None
    for ix in order.split(128):
        o.zero_grad(set_to_none=True); z,m=send(s,d['x'][ix],d['q'][ix],arm=='J-STE')
        loss=F.binary_cross_entropy_with_logits(receive(r,m,d['q'][ix],d['r'][ix]),d['y'][ix]) if arm=='J-STE' else F.binary_cross_entropy_with_logits(z,target[ix])
        loss.backward()
        if first is None:first={'loss':loss.detach().clone(),'grads':{k:v.grad.clone() for k,v in s.items()}}
        o.step()
    return first

def receiver_pass(s,r,d,order,o):
    for p in s.values():p.requires_grad_(False);p.grad=None
    for p in r.values():p.requires_grad_(True)
    first=None
    for ix in order.split(128):
        o.zero_grad(set_to_none=True)
        with torch.no_grad():_,m=send(s,d['x'][ix],d['q'][ix])
        loss=F.binary_cross_entropy_with_logits(receive(r,m,d['q'][ix],d['r'][ix]),d['y'][ix]);loss.backward()
        if first is None:first={'loss':loss.detach().clone(),'grads':{k:v.grad.clone() for k,v in r.items()}}
        o.step()
    return first

@torch.no_grad()
def score(r,d):
    # Explicit numeric enumeration, independent from training codes().
    c=torch.tensor([[(i//2**b)%2 for b in range(4)]+[0]*4 for i in range(16)],dtype=torch.float32)
    out=[]
    for st in range(0,len(d['q']),128):
        q=d['q'][st:st+128];rv=d['r'][st:st+128];y=d['y'][st:st+128]; n=len(q)
        z=receive(r,c.repeat(n,1),q.repeat_interleave(16),rv.repeat_interleave(16,0))
        out.append(F.binary_cross_entropy_with_logits(z,y.repeat_interleave(16,0),reduction='none').mean(1).reshape(n,16))
    return torch.cat(out)

def same(a,b):
    if isinstance(a,torch.Tensor):return isinstance(b,torch.Tensor) and torch.equal(a,b)
    if isinstance(a,dict):return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b

def load(p):return torch.load(p,map_location='cpu',weights_only=True)
def data(arr):return {k:torch.tensor(v,dtype=torch.int64 if k=='q' else torch.float32) for k,v in arr.items()}
def universe():
    ids=np.arange(8192);x=((ids//32)[:,None]//(2**np.arange(8)))%2;q=ids//16%2;r=(ids[:,None]//(2**np.arange(4)))%2
    # Actual step7/credit09 task: first three selected bits plus opposite block bit0;
    # task answer is addition modulo16, not the older all-selected-bits XOR task.
    v=np.array([[x[i,int(qq)*4+b] for b in range(3)]+[x[i,(1-int(qq))*4]] for i,qq in enumerate(q)])
    answer=((v*(2**np.arange(4))).sum(1)+ids%16)%16
    y=(answer[:,None]//(2**np.arange(4)))%2
    return {'x':x,'q':q,'r':r,'y':y},v

def entropy(counts):
    p=np.asarray(counts,dtype=float);p=p[p>0];p=p/p.sum();return float(-(p*np.log2(p)).sum()) if len(p) else 0.

def information(m,q,v):
    # One row per x,q; all r repeated uniformly in evaluation, so collapse first.
    mc=(m[::16,:4]*(2**np.arange(4))).sum(1).astype(int)
    vc=(v[::16]*(2**np.arange(4))).sum(1).astype(int);qc=q[::16];n=len(mc)
    counts=np.zeros((2,16,16),dtype=int);np.add.at(counts,(qc,mc,vc),1)
    ac=counts.max(2).sum()/n;hv=hm=hc=0.
    for qi in (0,1):
        weight=counts[qi].sum()/n;hv+=weight*entropy(counts[qi].sum(0));hm+=weight*entropy(counts[qi].sum(1))
        for mi in range(16):hc+=counts[qi,mi].sum()/n*entropy(counts[qi,mi])
    return {'A_code':float(ac),'H_V_given_q':hv,'H_V_given_Mq':hc,'I_V_M_given_q':hv-hc,'H_M_given_q':hm,'used_codes':int(len(np.unique(mc))),'max_code_share':float(np.bincount(mc,minlength=16).max()/n),'used_codes_per_q':[int((counts[i].sum(1)>0).sum()) for i in (0,1)]},mc

@torch.no_grad()
def evaluate(s,r,d,v,constants=False):
    _,m=send(s,d['x'],d['q']);z=receive(r,m,d['q'],d['r']);pred=(z>=0).cpu().numpy();y=d['y'].numpy().astype(bool)
    info,mc=information(m.numpy(),d['q'].numpy(),v)
    info.update(accuracy=float((pred==y).all(1).mean()),bit_accuracy=float((pred==y).mean()),task_bce=float(F.binary_cross_entropy_with_logits(z,d['y'])))
    assert info['accuracy']<=info['A_code']+1e-12
    assert np.all(m.numpy().reshape(-1,16,8)==m.numpy().reshape(-1,16,8)[:,:1])
    if constants:
        acc=[]
        for code in range(16):
            c=torch.tensor([(code//2**b)%2 for b in range(4)]+[0]*4,dtype=torch.float32).repeat(len(y),1)
            zz=receive(r,c,d['q'],d['r']);acc.append(float(((zz.numpy()>=0)==y).all(1).mean()))
        info.update(constant_accuracies=acc,constant_mean=float(np.mean(acc)),constant_drop=info['accuracy']-float(np.mean(acc)))
    return info,mc

def conflict(losses,previous):
    l=losses.numpy().reshape(256,16,16).astype(np.float64);t=l.argmin(2)
    bits=((t[:,:,None]//(2**np.arange(4)))%2);probs=bits.mean(1)
    counts=np.stack([np.bincount(row,minlength=16) for row in t]);regret=l.mean(1).min(1)-l.min(2).mean(1)
    assert regret.min()>=-1e-7
    result={'target_group_consistency':float((counts.max(1)==16).mean()),'target_modal_violation':float((1-counts.max(1)/16).mean()),'D':float(regret.mean()),'D_max':float(regret.max()),'bit_probability_near_half_fraction':float((np.abs(probs-.5)<=.125).mean()),'bit_probability_exact_half_fraction':float((probs==.5).mean()),'margin_mean':float(np.diff(np.sort(l,axis=2)[:,:,:2],axis=2).mean())}
    if previous is not None:
        result['target_flip']=float((t!=previous).mean());result['target_bit_flip']=((bits!=((previous[:,:,None]//(2**np.arange(4)))%2)).mean((0,1))).tolist()
    return result,t,probs

def main():
    run=Path(sys.argv[1]).resolve();setup();t0=time.monotonic();checks=[]
    def ck(name,ok):
        checks.append({'name':name,'passed':bool(ok)})
        if not ok:
            dump(run/'audit.json',{'passed':False,'checks':checks,'count':len(checks)});raise AssertionError(name)
    cfg=json.loads((run/'resolved_config.json').read_text())
    amendment=json.loads((run/'audit_amendment.json').read_text())
    for path,h in amendment['frozen_evidence'].items():ck('audit_correction_'+path,digest(path)==h)
    ck('training_completed',json.loads((run/'status.json').read_text())['status']=='completed_pending_audit')
    for rel,h in json.loads((run/'frozen_manifest.json').read_text()).items():ck('source_'+rel,digest(ROOT/rel)==h)
    for rel,h in json.loads((run/'input_manifest.json').read_text()).items():ck('input_'+rel,digest(run/rel)==h)
    for rel,h in json.loads((run/'training_manifest.json').read_text()).items():ck('sealed_'+rel,digest(run/rel)==h)
    for path,h in json.loads((run/'source_manifest.json').read_text()).items():ck('historical_'+path,digest(path)==h)
    ck('preflight',json.loads((run/'preflight.json').read_text())['passed'])
    u,v=universe();models=[];diagnostics={};old=ROOT.parent/'discrete_counterfactual_credit/results/20260907-exp09'
    for split in cfg['splits']:
        xp=np.random.Generator(np.random.PCG64(split)).permutation(256)
        ids={p:np.flatnonzero(np.isin(np.arange(8192)//32,xx)) for p,xx in [('train',xp[:128]),('validation',xp[128:160]),('test',xp[160:])]}
        ck(f'{split}_partition',len(set(ids['train'])&set(ids['test']))==0 and sorted(np.concatenate(list(ids.values())))==list(range(8192)))
        d=data({k:u[k][ids['train']] for k in u});vt=v[ids['train']]
        legal=dict(np.load(run/f'train_{split}.npz'));ck(f'{split}_legal_fields',set(legal)=={'x','q','r','y'})
        for k in u:ck(f'{split}_reconstructed_{k}',np.array_equal(legal[k],u[k][ids['train']]))
        for init in cfg['inits']:
            initials={};finals={}
            for arm in cfg['arms']:
                tag=f'{split}_{init}_{arm}';out=run/'models'/tag;initial=load(out/'epoch000.pt');initials[arm]=initial
                s=params(initial['sender']);r=params(initial['receiver']);so=opt(s);ro=None if arm=='P-E16' else opt(r)
                sg=torch.Generator().manual_seed(split*10000+init+2);rg=torch.Generator().manual_seed(split*10000+init+3)
                saved_order=np.load(out/'orders.npz');target=None;previous=None;prev_m=None;trajectory=[];probabilities=[];scored=0
                for epoch in range(1,101):
                    before_s={k:p.detach().clone() for k,p in s.items()};before_r={k:p.detach().clone() for k,p in r.items()}
                    if arm=='J-E16' or (arm=='P-E16' and epoch==1):
                        loss=score(r,d);scored+=4096*16;cache=torch.tensor(np.load(out/f'scores{epoch:03}.npy'))
                        ck(f'{tag}_{epoch}_scores',torch.equal(loss,cache))
                        targets=loss.argmin(1);target=((targets[:,None]//(2**torch.arange(4)))%2).float()
                    row={'epoch':epoch}
                    if arm=='J-E16':
                        c,previous,probs=conflict(loss,previous);row.update(c);probabilities.append(probs)
                    order=torch.randperm(4096,generator=sg);ck(f'{tag}_{epoch}_sender_order',np.array_equal(order.numpy(),saved_order['sender'][epoch-1]))
                    if arm!='P-E16':row['before'],_=evaluate(s,r,d,vt)
                    fs=sender_pass(s,r,d,order,arm,target,so)
                    if epoch==1:ck(tag+'_first_sender_gradient',same(fs,load(out/'first_sender.pt')))
                    mid=load(out/f'epoch{epoch:03}_sender.pt')
                    ck(f'{tag}_{epoch}_sender_stage',same(s,mid['sender']) and same(r,mid['receiver']) and same(so.state_dict(),mid['sender_optimizer']) and same(None if ro is None else ro.state_dict(),mid['receiver_optimizer']))
                    ck(f'{tag}_{epoch}_receiver_frozen',same(r,before_r))
                    if arm!='P-E16':
                        row['after_sender'],_=evaluate(s,r,d,vt)
                        order_r=torch.randperm(4096,generator=rg);ck(f'{tag}_{epoch}_receiver_order',np.array_equal(order_r.numpy(),saved_order['receiver'][epoch-1]))
                        fr=receiver_pass(s,r,d,order_r,ro)
                        if epoch==1:ck(tag+'_first_receiver_gradient',same(fr,load(out/'first_receiver.pt')))
                    end=load(out/f'epoch{epoch:03}.pt')
                    ck(f'{tag}_{epoch}_end_stage',same(s,end['sender']) and same(r,end['receiver']) and same(so.state_dict(),end['sender_optimizer']) and same(None if ro is None else ro.state_dict(),end['receiver_optimizer']))
                    ck(f'{tag}_{epoch}_sender_frozen',same(s,mid['sender']))
                    if arm!='P-E16':
                        row['after_receiver'],mc=evaluate(s,r,d,vt)
                        if prev_m is not None:row['message_flip']=float((mc!=prev_m).mean())
                        prev_m=mc
                        if arm=='J-E16':
                            _,mm=send(s,d['x'],d['q']);tb=target.numpy();actual=mm.detach().numpy()[:,:4]
                            row['target_bit_fit']=float((actual==tb).mean());row['target_code_fit']=float((actual==tb).all(1).mean())
                        trajectory.append(row)
                final=load(out/'checkpoint.pt');finals[arm]=final
                ck(tag+'_final',same(s,final['sender']) and same(r,final['receiver']))
                ck(tag+'_finite',all(torch.isfinite(p).all() for p in list(s.values())+list(r.values())))
                meta=json.loads((out/'training.json').read_text());expected_queries=0 if arm=='J-STE' else 4096*16*(100 if arm=='J-E16' else 1)
                ck(tag+'_budget',scored==meta['candidate_queries']==expected_queries and meta['sender_updates']==3200 and meta['receiver_updates']==(0 if arm=='P-E16' else 3200))
                ck(tag+'_optimizer_steps',all(int(st['step'])==3200 for st in so.state_dict()['state'].values()) and (ro is None or all(int(st['step'])==3200 for st in ro.state_dict()['state'].values())))
                expected_inputs=[str(run/f'train_{split}.npz')]+([str(run/'anchors'/f'{split}_{init}.pt')] if arm=='P-E16' else [])
                ck(tag+'_read_whitelist',meta['project_inputs_read']==sorted(expected_inputs))
                metrics={'split':split,'init':init,'arm':arm,'cost':meta}
                for part,ix in ids.items():metrics[part],_=evaluate(s,r,data({k:u[k][ix] for k in u}),v[ix],constants=part=='test')
                if arm=='P-E16':
                    hist=load(old/'models'/f'{split}_{init}_E16-hard'/'checkpoint.pt')
                    ck(tag+'_historical_exact_final',same(final,hist));ck(tag+'_historical_first_gradient',same(load(out/'first_sender.pt')['grads'],load(old/'models'/f'{split}_{init}_E16-hard'/'first_step.pt')['gradients']))
                # Cross-check independent forward path against production module prediction.
                from core import Sender,Receiver,predict
                ns=Sender();nr=Receiver();ns.load_state_dict(final['sender']);nr.load_state_dict(final['receiver'])
                td=data({k:u[k][ids['test']] for k in u});_,nz,_=predict(ns,nr,td)
                with torch.no_grad():_,fm=send(s,td['x'],td['q']);fz=receive(r,fm,td['q'],td['r'])
                ck(tag+'_independent_predictions',torch.equal(nz,fz))
                models.append(metrics);diagnostics[tag]=trajectory
                if probabilities:np.savez_compressed(run/f'{tag}_target_bit_probabilities.npz',probabilities=np.array(probabilities))
                dump(run/'audit_progress.json',{'models_replayed':len(models),'checks':len(checks),'seconds':time.monotonic()-t0})
                print(f'Audit {len(models)}/18: {tag} exact replay passed',flush=True)
            ck(f'{split}_{init}_joint_initial_pair',same(initials['J-E16'],initials['J-STE']))
            ck(f'{split}_{init}_sender_initial_pair',same(initials['P-E16']['sender'],initials['J-E16']['sender']))
            # Independent architecture initialization reconstruction uses raw Linear layout.
            from core import Sender,Receiver
            with torch.random.fork_rng():
                torch.manual_seed(init+200000);ss=Sender();torch.manual_seed(init+700000);rr=Receiver()
            ck(f'{split}_{init}_random_initial',same(ss.state_dict(),initials['J-E16']['sender']) and same(rr.state_dict(),initials['J-E16']['receiver']))
    ck('18_models',len(models)==18)
    pairs=[]
    for split in cfg['splits']:
        for init in cfg['inits']:
            mm={m['arm']:m for m in models if m['split']==split and m['init']==init}
            pairs.append({'split':split,'init':init,'difference':mm['J-E16']['test']['accuracy']-mm['J-STE']['test']['accuracy']})
    recovery={arm:all(m['test']['accuracy']>=.95 and m['test']['A_code']>=.95 and m['test']['constant_drop']>=.8 for m in models if m['arm']==arm) for arm in cfg['arms']}
    mean=float(np.mean([p['difference'] for p in pairs]));splits={str(s):float(np.mean([p['difference'] for p in pairs if p['split']==s])) for s in cfg['splits']}
    gates={'G0_valid':True,'G1_J_E16_recovery':recovery['J-E16'],'G2_advantage':mean>=.1 and all(x>0 for x in splits.values()),'recovery_by_arm':recovery,'mean_paired_advantage':mean,'split_advantages':splits}
    dump(run/'metrics.json',models);dump(run/'diagnostics.json',diagnostics);dump(run/'paired_results.json',pairs)
    dump(run/'audit.json',{'passed':True,'count':len(checks),'checks':checks,'gates':gates,'elapsed_seconds':time.monotonic()-t0,'external_replication':False,'full_optimizer_replay':True,'audit_candidate_scores':39714816,'trajectory_forward_states':14745600,'final_evaluation_forward_states':18*8192,'constant_intervention_forward_states':18*16*3072,'extra_prediction_crosscheck_states':18*2*3072})
    print(json.dumps(gates,indent=2),flush=True)
if __name__=='__main__':main()
