"""Verify packaged files using only Python standard library."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_text())
bad=[]
for rel,meta in manifest['files'].items():
    p=root/rel
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=meta['sha256']:
        bad.append(rel)
print(json.dumps({'checked':len(manifest['files']),'passed':not bad,'failures':bad},ensure_ascii=False))
if bad:raise SystemExit(1)
