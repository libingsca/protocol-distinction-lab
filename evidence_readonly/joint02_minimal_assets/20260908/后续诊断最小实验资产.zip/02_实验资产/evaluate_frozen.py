"""Read-only final checkpoint check; no training and no historical audit replay."""
import argparse, json, sys
from pathlib import Path

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    output=Path(args.output).resolve()
    if output.is_relative_to(root):
        raise SystemExit('Output must be outside the read-only asset directory')
    sys.dont_write_bytecode=True
    import numpy as np
    import torch
    sys.path.insert(0,str(root/'frozen_sources'))
    from audit_v2 import universe, params, data, evaluate
    torch.set_num_threads(1)
    u,v=universe()
    with np.load(root/'evaluation_only/evaluation_only.npz') as ref:
        for k in u:
            if not np.array_equal(u[k],ref[k]): raise AssertionError('universe '+k)
        if not np.array_equal(v,ref['v']): raise AssertionError('universe v')
    expected=json.loads((root/'historical_run/metrics.json').read_text())
    results=[]
    for model in expected:
        split,init,arm=model['split'],model['init'],model['arm']
        tag=f'{split}_{init}_{arm}'
        checkpoint=torch.load(root/'models'/tag/'checkpoint.pt',map_location='cpu',weights_only=True)
        s,r=params(checkpoint['sender']),params(checkpoint['receiver'])
        permutation=np.random.Generator(np.random.PCG64(split)).permutation(256)
        partitions={'train':permutation[:128],'validation':permutation[128:160],'test':permutation[160:]}
        for part,xs in partitions.items():
            rows=np.flatnonzero(np.isin(np.arange(8192)//32,xs))
            actual,_=evaluate(s,r,data({k:a[rows] for k,a in u.items()}),v[rows])
            diffs={k:abs(actual[k]-model[part][k]) for k in ['accuracy','A_code','I_V_M_given_q']}
            results.append({'model':tag,'partition':part,'absolute_differences':diffs,'passed':all(z<=1e-6 for z in diffs.values())})
    report={'scope':'final evaluation only, not training replay','numpy':np.__version__,'torch':torch.__version__,'passed':all(r['passed'] for r in results),'checks':results}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'evaluations':len(results),'output':str(output)}))
    if not report['passed']: raise SystemExit(1)

if __name__=='__main__': main()
